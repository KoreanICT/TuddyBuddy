import { createContext, useContext, useEffect, useState } from "react";
import { fetchEventSource } from '@microsoft/fetch-event-source';
import { NotificationData } from "./NotificationAPI";
import { useSelector } from 'react-redux';
import { RootState } from "../login/reducers";
import store from "../login/reducers/store";


interface NotificationContextType {
    notifications: NotificationData[];
}

const NotificationContext = createContext<NotificationContextType>({
    notifications: []
})

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {

    const [notifications, setNotifications] = useState<NotificationData[]>([]);
    const token = useSelector((state: RootState) => state.auth.token)
    const { member_num } = store.getState().auth;
    useEffect(() => {

        if (!token || member_num === null) {
            return;
        }

        const controller = new AbortController();

        fetchEventSource('http://localhost/back/api/notification/subscribe',
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                    member_num: String(member_num)
                },
                signal: controller.signal,
                onmessage(event) {
                    if (event.event !== 'notification') {
                        return;
                    }

                    const data = JSON.parse(event.data) as NotificationData;

                    setNotifications((prev) => [data, ...prev]);
                }
            }
        );
        return () => {controller.abort()};
    },[token])

    return (
        <NotificationContext.Provider value={{notifications}}>
            {children}
        </NotificationContext.Provider>
    );
};

export const useNotification = () =>  useContext(NotificationContext);